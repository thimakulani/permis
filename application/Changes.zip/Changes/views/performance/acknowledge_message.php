
<div class="m-2">
	<div class="card">
		<div class="card-header">
			<h1 class="site-header__title" data-lead-id="site-header-title">THANK YOU!</h1>
		</div>
		<div class="card-body">
			<p>Thank you for submitting you`re performance tool.</p> <a href="<?php echo base_url() ?>performance" class="btn-sm btn-primary ml-1">Got it</a>
		</div>
	</div>
</div>
