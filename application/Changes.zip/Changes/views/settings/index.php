<div class="row">
		<a href="<?php echo base_url()?>districts" style="margin: 10px" class="card text-white text-decoration-none p-3 bg-info">
			DISTRICTS
		</a>
		<a href="<?php echo base_url()?>position" style="margin: 10px" class="card text-white text-decoration-none p-3 bg-info">
			JOB TITLE
		</a>
		<a href="<?php echo base_url()?>businessunit" style="margin: 10px" class="card text-white text-decoration-none p-3 bg-info">
			DIRECTORATES
		</a>
		<a href="<?php echo base_url()?>businessunit/sub_directorate" style="margin: 10px" class="card text-white text-decoration-none p-3 bg-info">
			SUB-DIRECTORATES
		</a>
		<a href="<?php echo base_url()?>branch" style="margin: 10px" class="card text-white text-decoration-none p-3 bg-info">
			BRANCH
		</a>

</div>
<!-- /.row -->
