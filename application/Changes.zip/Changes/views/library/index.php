<div class="card">
	<div class="card-header">
		<h5>LIBRARY</h5>
	</div>
	<div class="row card-body">
		<a class="btn-lg btn-success text-decoration-none" style="margin: 5px" href="<?php echo base_url() ?>library/memo_and_schedule">MEMO AND SCHEDULE</a>
		<a class="btn-lg btn-success text-decoration-none" style="margin: 5px" href="<?php echo base_url() ?>library/monthly_and_quarterly">MONTHLY AND QUARTERLY</a>
		<a class="btn-lg btn-success text-decoration-none" style="margin: 5px" href="<?php echo base_url() ?>library/minutes">MINUTES</a>
		<a class="btn-lg btn-success text-decoration-none" style="margin: 5px" href="<?php echo base_url() ?>library/attendance_register">ATTENDANCE REGISTER </a>
	</div>
</div>
