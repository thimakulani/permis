<h1>Details</h1>

<div>
	<hr />
	<dl class="row">
		<dt class = "col-sm-2">
			Name
		</dt>
		<dd class = "col-sm-10">
			<?php //echo $name?>
		</dd>
	</dl>
</div>
<div>
	<a class="btn-sm btn-primary" href="<?php echo base_url()?>districts/edit">Edit</a> |
	<a class="btn-sm btn-primary" href="<?php echo base_url()?>districts">Back to List</a>
</div>
