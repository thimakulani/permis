<!DOCTYPE html>
<html>
<head>
	<!-- <title>My Pages for Alert</title> -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/3.2.1/css/font-awesome.min.css" rel="stylesheet" />
</head>
<body>


<div>
	<?php
	$this->load->view('alert');
	?>
</div>


</body>
</html>
