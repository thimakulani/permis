<div class="card">
	<div class="card-header">
		<h3>INSTRUMENTS</h3>
	</div>
	<br>
	<div class="card-body p-0 table-responsive-sm">
		<a type="button" href="<?php echo base_url() ?>Pmd_Officials/reviewed" class="form-control btn-outline-primary">VIEW RECOMMENDED INSTRUMENTS</a>
	</div>
	<br>
	<div class="card-body p-0 table-responsive-sm">
		<a type="button" href="<?php echo base_url() ?>Pmd_Officials/disputed" class="form-control btn-outline-danger">VIEW DISPUTED INSTRUMENTS</a>
	</div>


</div>
