<div class="card">
	<div class="card-body">
		<div class="row">
			<div class="col-md-3 col-sm-6 col-12">
				<a href="<?php echo base_url(); ?>reports/employeerep" class="text-white card p-4 text-decoration-none bg-info">
					EMPLOYEES
					<!-- /.info-box-content -->
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->
			<div class="col-md-3 col-sm-6 col-12">
				<a href="<?php echo base_url(); ?>reports/none_compliant" class="text-white p-4 card text-decoration-none bg-primary">

					NON-COMPLIANT
					<!-- /.info-box-content -->
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->
			<div class="col-md-3 col-sm-6 col-12">
				<a href="<?php echo base_url(); ?>reports/compliant" class="p-4 text-white card text-decoration-none bg-info">

					COMPLIANT
					<!-- /.info-box-content -->
				</a>
				<!-- /.info-box -->
			</div>
			<div class="col-md-3 col-sm-6 col-12">
				<a href="<?php echo base_url(); ?>reports/track" class="p-4 text-white card text-decoration-none bg-info">

					TRACK
					<!-- /.info-box-content -->
				</a>
				<!-- /.info-box -->
			</div>

			<!-- /.col -->
		</div>
	</div>
</div>
