<div class="card">
	<div class="card-body">
		<div class="row">
			<div class="col-md-3 col-sm-6 col-12">
				<a href="#" class="info-box bg-info">
					<span class="info-box-icon"><i class="far fa-torii-gate"></i></span>
					<div class="info-box-content">
						<span class="info-box-text">PDF DOCUMENT</span>
					</div>
					<!-- /.info-box-content -->
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->
			<div class="col-md-3 col-sm-6 col-12">
				<a href="#" class="info-box bg-primary">
					<span class="info-box-icon"><i class="fa-thin fa-assistive-listening-systems"></i></span>

					<div class="info-box-content">
						<span class="info-box-text">VIDEO</span>
					</div>
					<!-- /.info-box-content -->
				</a>
				<!-- /.info-box -->
			</div>
			<!-- /.col -->

			<!-- /.col -->
		</div>
	</div>
</div>
